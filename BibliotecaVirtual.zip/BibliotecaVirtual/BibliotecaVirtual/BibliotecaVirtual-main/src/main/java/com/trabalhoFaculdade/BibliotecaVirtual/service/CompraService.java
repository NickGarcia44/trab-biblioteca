package com.trabalhoFaculdade.BibliotecaVirtual.service;

import com.trabalhoFaculdade.BibliotecaVirtual.entity.Compra;
import com.trabalhoFaculdade.BibliotecaVirtual.entity.Livro;
import com.trabalhoFaculdade.BibliotecaVirtual.entity.Usuario;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.CompraRepository;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.LivroRepository;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CompraService {

    private final CompraRepository compraRepository;
    private final LivroRepository livroRepository;
    private final UsuarioRepository usuarioRepository;

    public Compra realizarCompra(Long livroId, String email) {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado!"));

        Livro livro = livroRepository.findById(livroId)
                .orElseThrow(() -> new RuntimeException("Livro não encontrado!"));

        boolean jaComprou = usuario.getLivros().stream()
                .anyMatch(l -> l.getId().equals(livroId));

        if (jaComprou) {
            throw new RuntimeException("Você já comprou este livro!");
        }

        usuario.getLivros().add(livro);
        usuarioRepository.save(usuario);

        Compra compra = Compra.builder()
                .usuario(usuario)
                .livro(livro)
                .dataCompra(LocalDateTime.now())
                .build();

        return compraRepository.save(compra);
    }

    public List<Livro> listarLivrosComprados(String email) {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado!"));

        return usuario.getLivros();
    }
}