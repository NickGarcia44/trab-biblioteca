package com.trabalhoFaculdade.BibliotecaVirtual.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AdminDashboardDTO {
    private long totalLivros;
    private long totalUsuarios;
    private long totalCompras;
}
