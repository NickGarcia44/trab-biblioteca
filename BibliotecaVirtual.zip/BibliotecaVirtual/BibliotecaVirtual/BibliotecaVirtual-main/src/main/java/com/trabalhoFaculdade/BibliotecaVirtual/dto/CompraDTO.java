package com.trabalhoFaculdade.BibliotecaVirtual.dto;

import lombok.Data;

@Data
public class CompraDTO {
    private Long livroId;
}