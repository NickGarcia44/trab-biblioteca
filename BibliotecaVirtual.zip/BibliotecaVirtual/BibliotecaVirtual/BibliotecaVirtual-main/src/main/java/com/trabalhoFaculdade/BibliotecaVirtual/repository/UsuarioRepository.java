package com.trabalhoFaculdade.BibliotecaVirtual.repository;

import com.trabalhoFaculdade.BibliotecaVirtual.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmail(String email);
}