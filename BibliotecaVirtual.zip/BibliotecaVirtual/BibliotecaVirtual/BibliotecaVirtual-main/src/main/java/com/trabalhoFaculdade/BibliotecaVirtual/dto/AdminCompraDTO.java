package com.trabalhoFaculdade.BibliotecaVirtual.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class AdminCompraDTO {
    private Long id;
    private String usuarioNome;
    private String usuarioEmail;
    private String livroTitulo;
    private LocalDateTime dataCompra;
}
