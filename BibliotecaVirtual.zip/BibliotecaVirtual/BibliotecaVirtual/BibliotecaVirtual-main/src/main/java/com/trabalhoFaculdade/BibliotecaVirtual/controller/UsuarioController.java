package com.trabalhoFaculdade.BibliotecaVirtual.controller;

import com.trabalhoFaculdade.BibliotecaVirtual.dto.RegisterRequest;
import com.trabalhoFaculdade.BibliotecaVirtual.dto.UsuarioDTO;
import com.trabalhoFaculdade.BibliotecaVirtual.service.UsuarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/usuarios")
@RequiredArgsConstructor
public class UsuarioController {

    private final UsuarioService usuarioService;

    @GetMapping("/perfil")
    public ResponseEntity<UsuarioDTO> perfil(@AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(usuarioService.buscarPerfil(userDetails.getUsername()));
    }

    @PutMapping("/atualizar")
    public ResponseEntity<UsuarioDTO> atualizar(@AuthenticationPrincipal UserDetails userDetails,
                                                @Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(usuarioService.atualizar(userDetails.getUsername(), request));
    }
}