package com.trabalhoFaculdade.BibliotecaVirtual.repository;

import com.trabalhoFaculdade.BibliotecaVirtual.entity.Livro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LivroRepository extends JpaRepository<Livro, Long> {
}