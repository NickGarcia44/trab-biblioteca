package com.trabalhoFaculdade.BibliotecaVirtual.repository;

import com.trabalhoFaculdade.BibliotecaVirtual.entity.Compra;
import com.trabalhoFaculdade.BibliotecaVirtual.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CompraRepository extends JpaRepository<Compra, Long> {
    List<Compra> findByUsuario(Usuario usuario);
}