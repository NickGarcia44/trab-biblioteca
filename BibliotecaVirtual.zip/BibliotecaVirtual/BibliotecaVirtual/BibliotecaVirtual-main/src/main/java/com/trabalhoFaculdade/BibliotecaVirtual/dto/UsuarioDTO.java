package com.trabalhoFaculdade.BibliotecaVirtual.dto;

import com.trabalhoFaculdade.BibliotecaVirtual.enums.Role;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class UsuarioDTO {
    private Long id;
    private String nomeCompleto;
    private String email;
    private Role role;
    private List<LivroDTO> livros;
}