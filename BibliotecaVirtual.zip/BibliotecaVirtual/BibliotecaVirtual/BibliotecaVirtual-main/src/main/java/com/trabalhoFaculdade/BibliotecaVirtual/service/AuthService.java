package com.trabalhoFaculdade.BibliotecaVirtual.service;

import com.trabalhoFaculdade.BibliotecaVirtual.dto.LoginRequest;
import com.trabalhoFaculdade.BibliotecaVirtual.dto.RegisterRequest;
import com.trabalhoFaculdade.BibliotecaVirtual.entity.Usuario;
import com.trabalhoFaculdade.BibliotecaVirtual.enums.Role;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.UsuarioRepository;
import com.trabalhoFaculdade.BibliotecaVirtual.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;

    public String register(RegisterRequest request) {
        if (usuarioRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Email já cadastrado!");
        }

        Usuario usuario = Usuario.builder()
                .nomeCompleto(request.getNomeCompleto())
                .email(request.getEmail())
                .senha(passwordEncoder.encode(request.getSenha()))
                .role(Role.USER)
                .livros(new java.util.ArrayList<>())
                .build();

        usuarioRepository.save(usuario);
        return jwtUtil.gerarToken(usuario.getEmail());
    }

    public String login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getSenha()
                )
        );

        Usuario usuario = usuarioRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado!"));

        return jwtUtil.gerarToken(usuario.getEmail());
    }
}