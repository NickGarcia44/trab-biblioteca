package com.trabalhoFaculdade.BibliotecaVirtual;

import com.trabalhoFaculdade.BibliotecaVirtual.entity.Livro;
import com.trabalhoFaculdade.BibliotecaVirtual.entity.Usuario;
import com.trabalhoFaculdade.BibliotecaVirtual.enums.Role;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.LivroRepository;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;
import java.util.ArrayList;

@SpringBootApplication
@RequiredArgsConstructor
public class BibliotecaVirtualApplication {

    public static void main(String[] args) {
        SpringApplication.run(BibliotecaVirtualApplication.class, args);
    }

    @Bean
    public CommandLineRunner popularBanco(UsuarioRepository usuarioRepository,
                                          LivroRepository livroRepository,
                                          PasswordEncoder passwordEncoder) {
        return args -> {
            if (usuarioRepository.findByEmail("admin@biblioteca.com").isEmpty()) {
                Usuario admin = Usuario.builder()
                        .nomeCompleto("Administrador")
                        .email("admin@biblioteca.com")
                        .senha(passwordEncoder.encode("admin123"))
                        .role(Role.ADMIN)
                        .livros(new ArrayList<>())
                        .build();
                usuarioRepository.save(admin);
                System.out.println("Admin criado com sucesso!");
            }

            if (livroRepository.count() == 0) {
                livroRepository.save(Livro.builder()
                        .titulo("Aprenda Domain-Driven Design")
                        .nomeAutor("Vlad Khononov")
                        .anoEdicao("2024")
                        .preco(new BigDecimal("57.50"))
                        .build());

                livroRepository.save(Livro.builder()
                        .titulo("Fundamentos da Arquitetura de Software")
                        .nomeAutor("Mark Richards")
                        .anoEdicao("2025")
                        .preco(new BigDecimal("108.30"))
                        .build());

                livroRepository.save(Livro.builder()
                        .titulo("Arquitetura de software: as partes difíceis")
                        .nomeAutor("Neal Ford")
                        .anoEdicao("2024")
                        .preco(new BigDecimal("66.95"))
                        .build());
            }
        };
    }
}
