package com.trabalhoFaculdade.BibliotecaVirtual.enums;

public enum Role {
    ADMIN,
    USER
}
