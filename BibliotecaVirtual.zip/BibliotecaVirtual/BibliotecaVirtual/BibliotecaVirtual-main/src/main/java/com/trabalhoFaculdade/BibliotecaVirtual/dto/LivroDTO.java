package com.trabalhoFaculdade.BibliotecaVirtual.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class LivroDTO {

    @NotBlank
    private String titulo;

    @NotBlank
    private String nomeAutor;

    @NotBlank
    private String anoEdicao;

    @NotNull
    private BigDecimal preco;
}