package com.trabalhoFaculdade.BibliotecaVirtual.service;

import com.trabalhoFaculdade.BibliotecaVirtual.dto.LivroDTO;
import com.trabalhoFaculdade.BibliotecaVirtual.entity.Livro;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.LivroRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class LivroService {

    private final LivroRepository livroRepository;

    public List<Livro> listarTodos() {
        return livroRepository.findAll();
    }

    public Livro cadastrar(LivroDTO dto) {
        Livro livro = Livro.builder()
                .titulo(dto.getTitulo())
                .nomeAutor(dto.getNomeAutor())
                .anoEdicao(dto.getAnoEdicao())
                .preco(dto.getPreco())
                .build();

        return livroRepository.save(livro);
    }

    public Livro atualizar(Long id, LivroDTO dto) {
        Livro livro = livroRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Livro não encontrado!"));

        livro.setTitulo(dto.getTitulo());
        livro.setNomeAutor(dto.getNomeAutor());
        livro.setAnoEdicao(dto.getAnoEdicao());
        livro.setPreco(dto.getPreco());

        return livroRepository.save(livro);
    }

    public void excluir(Long id) {
        if (!livroRepository.existsById(id)) {
            throw new RuntimeException("Livro não encontrado!");
        }
        livroRepository.deleteById(id);
    }
}
