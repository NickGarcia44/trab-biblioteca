package com.trabalhoFaculdade.BibliotecaVirtual.service;

import com.trabalhoFaculdade.BibliotecaVirtual.dto.LivroDTO;
import com.trabalhoFaculdade.BibliotecaVirtual.dto.RegisterRequest;
import com.trabalhoFaculdade.BibliotecaVirtual.dto.UsuarioDTO;
import com.trabalhoFaculdade.BibliotecaVirtual.entity.Usuario;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final PasswordEncoder passwordEncoder;

    private final UsuarioRepository usuarioRepository;

    public UsuarioDTO atualizar(String email, RegisterRequest request) {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado!"));

        if (!email.equals(request.getEmail()) &&
                usuarioRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Este email já está em uso!");
        }

        usuario.setNomeCompleto(request.getNomeCompleto());
        usuario.setEmail(request.getEmail());
        usuario.setSenha(passwordEncoder.encode(request.getSenha()));

        usuarioRepository.save(usuario);

        return UsuarioDTO.builder()
                .id(usuario.getId())
                .nomeCompleto(usuario.getNomeCompleto())
                .email(usuario.getEmail())
                .role(usuario.getRole())
                .livros(new java.util.ArrayList<>())
                .build();
    }

    public UsuarioDTO buscarPerfil(String email) {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado!"));

        List<LivroDTO> livrosDTO = usuario.getLivros().stream()
                .map(livro -> {
                    LivroDTO dto = new LivroDTO();
                    dto.setTitulo(livro.getTitulo());
                    dto.setNomeAutor(livro.getNomeAutor());
                    dto.setAnoEdicao(livro.getAnoEdicao());
                    dto.setPreco(livro.getPreco());
                    return dto;
                }).toList();

        return UsuarioDTO.builder()
                .id(usuario.getId())
                .nomeCompleto(usuario.getNomeCompleto())
                .email(usuario.getEmail())
                .role(usuario.getRole())
                .livros(livrosDTO)
                .build();
    }
}