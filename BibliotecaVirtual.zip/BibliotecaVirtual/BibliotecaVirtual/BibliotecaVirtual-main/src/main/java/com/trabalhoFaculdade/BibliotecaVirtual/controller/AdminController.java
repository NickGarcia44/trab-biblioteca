package com.trabalhoFaculdade.BibliotecaVirtual.controller;

import com.trabalhoFaculdade.BibliotecaVirtual.dto.AdminCompraDTO;
import com.trabalhoFaculdade.BibliotecaVirtual.dto.AdminDashboardDTO;
import com.trabalhoFaculdade.BibliotecaVirtual.dto.UsuarioDTO;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.CompraRepository;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.LivroRepository;
import com.trabalhoFaculdade.BibliotecaVirtual.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final LivroRepository livroRepository;
    private final UsuarioRepository usuarioRepository;
    private final CompraRepository compraRepository;

    @GetMapping("/dashboard")
    public ResponseEntity<AdminDashboardDTO> dashboard() {
        return ResponseEntity.ok(new AdminDashboardDTO(
                livroRepository.count(),
                usuarioRepository.count(),
                compraRepository.count()
        ));
    }

    @GetMapping("/usuarios")
    public ResponseEntity<List<UsuarioDTO>> listarUsuarios() {
        List<UsuarioDTO> usuarios = usuarioRepository.findAll().stream()
                .map(usuario -> UsuarioDTO.builder()
                        .id(usuario.getId())
                        .nomeCompleto(usuario.getNomeCompleto())
                        .email(usuario.getEmail())
                        .role(usuario.getRole())
                        .build())
                .toList();

        return ResponseEntity.ok(usuarios);
    }

    @GetMapping("/compras")
    public ResponseEntity<List<AdminCompraDTO>> listarCompras() {
        List<AdminCompraDTO> compras = compraRepository.findAll().stream()
                .map(compra -> new AdminCompraDTO(
                        compra.getId(),
                        compra.getUsuario().getNomeCompleto(),
                        compra.getUsuario().getEmail(),
                        compra.getLivro().getTitulo(),
                        compra.getDataCompra()
                ))
                .toList();

        return ResponseEntity.ok(compras);
    }
}
