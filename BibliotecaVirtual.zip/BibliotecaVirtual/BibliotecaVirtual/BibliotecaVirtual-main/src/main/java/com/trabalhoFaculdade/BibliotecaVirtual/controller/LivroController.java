package com.trabalhoFaculdade.BibliotecaVirtual.controller;

import com.trabalhoFaculdade.BibliotecaVirtual.dto.LivroDTO;
import com.trabalhoFaculdade.BibliotecaVirtual.entity.Livro;
import com.trabalhoFaculdade.BibliotecaVirtual.service.LivroService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/livros")
@RequiredArgsConstructor
public class LivroController {

    private final LivroService livroService;

    @GetMapping
    public ResponseEntity<List<Livro>> listarTodos() {
        return ResponseEntity.ok(livroService.listarTodos());
    }

    @PostMapping
    public ResponseEntity<Livro> cadastrar(@Valid @RequestBody LivroDTO dto) {
        return ResponseEntity.ok(livroService.cadastrar(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Livro> atualizar(@PathVariable Long id,
                                           @Valid @RequestBody LivroDTO dto) {
        return ResponseEntity.ok(livroService.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        livroService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
