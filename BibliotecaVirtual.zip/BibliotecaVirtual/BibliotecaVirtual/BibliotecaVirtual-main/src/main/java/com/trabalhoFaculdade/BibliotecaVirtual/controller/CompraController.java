package com.trabalhoFaculdade.BibliotecaVirtual.controller;

import com.trabalhoFaculdade.BibliotecaVirtual.entity.Compra;
import com.trabalhoFaculdade.BibliotecaVirtual.entity.Livro;
import com.trabalhoFaculdade.BibliotecaVirtual.service.CompraService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/compras")
@RequiredArgsConstructor
public class CompraController {

    private final CompraService compraService;

    @PostMapping("/{livroId}")
    public ResponseEntity<Compra> realizarCompra(@PathVariable Long livroId,
                                                 @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(compraService.realizarCompra(livroId, userDetails.getUsername()));
    }

    @GetMapping("/meus-livros")
    public ResponseEntity<List<Livro>> listarLivrosComprados(
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(compraService.listarLivrosComprados(userDetails.getUsername()));
    }
}