const form = document.getElementById('cadastro-form');
const mensagem = document.getElementById('mensagem');

form.addEventListener('submit', async (event) => {
    event.preventDefault();

    const nomeCompleto = document.getElementById('nomeCompleto').value.trim();
    const email = document.getElementById('email').value.trim();
    const senha = document.getElementById('senha').value;
    const confirmarSenha = document.getElementById('confirmarSenha').value;

    if (senha !== confirmarSenha) {
        mensagem.textContent = 'As senhas não conferem.';
        return;
    }

    mensagem.textContent = 'Cadastrando...';

    try {
        const response = await fetch('/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nomeCompleto, email, senha })
        });

        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(data.message || data.error || 'Não foi possível cadastrar.');
        }

        localStorage.setItem('token', data.token);
        window.location.href = '/home/home.html';
    } catch (error) {
        mensagem.textContent = error.message;
    }
});
