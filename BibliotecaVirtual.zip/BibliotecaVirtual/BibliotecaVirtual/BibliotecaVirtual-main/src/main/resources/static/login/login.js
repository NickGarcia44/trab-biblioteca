const form = document.getElementById('login-form');
const mensagem = document.getElementById('mensagem');

form.addEventListener('submit', async (event) => {
    event.preventDefault();

    const email = document.getElementById('login').value.trim();
    const senha = document.getElementById('senha').value;

    mensagem.textContent = 'Entrando...';

    try {
        const response = await fetch('/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, senha })
        });

        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(data.message || data.error || 'E-mail ou senha inválidos.');
        }

        localStorage.setItem('token', data.token);
        window.location.href = '/home/home.html';
    } catch (error) {
        mensagem.textContent = error.message;
    }
});
