const form = document.getElementById('admin-form');
const mensagem = document.getElementById('mensagem');

form.addEventListener('submit', async (event) => {
    event.preventDefault();

    const email = document.getElementById('login-admin').value.trim();
    const senha = document.getElementById('senha-admin').value;

    mensagem.textContent = 'Entrando...';

    try {
        const loginResponse = await fetch('/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, senha })
        });

        const loginData = await loginResponse.json().catch(() => ({}));

        if (!loginResponse.ok) {
            throw new Error(loginData.message || loginData.error || 'Login inválido.');
        }

        const perfilResponse = await fetch('/usuarios/perfil', {
            headers: { Authorization: `Bearer ${loginData.token}` }
        });

        const perfil = await perfilResponse.json().catch(() => ({}));

        if (!perfilResponse.ok || perfil.role !== 'ADMIN') {
            throw new Error('Este usuário não possui permissão de administrador.');
        }

        localStorage.setItem('token', loginData.token);
        window.location.href = '/admin/painel-admin.html';
    } catch (error) {
        mensagem.textContent = error.message;
    }
});
