const numberInput = document.getElementById('number-input');
const nameInput = document.getElementById('name-input');
const dateInput = document.getElementById('date-input');
const cvvInput = document.getElementById('cvv-input');
const form = document.getElementById('pagamento-form');
const mensagem = document.getElementById('mensagem');

const cardNumber = document.getElementById('card-number');
const cardName = document.getElementById('card-name');
const cardDate = document.getElementById('card-date');
const cardCvv = document.getElementById('card-cvv');
const card = document.getElementById('card');

const token = localStorage.getItem('token');
const livroId = localStorage.getItem('livroSelecionadoId');

if (!token) {
    window.location.href = '/login/login.html';
}

if (!livroId) {
    mensagem.textContent = 'Nenhum livro selecionado. Volte para a loja e escolha um livro.';
}

numberInput.addEventListener('input', () => {
    const value = numberInput.value
        .replace(/\D/g, '')
        .replace(/(.{4})/g, '$1 ')
        .trim();

    numberInput.value = value;
    cardNumber.textContent = value || '0000 0000 0000 0000';
});

nameInput.addEventListener('input', () => {
    cardName.textContent = nameInput.value.toUpperCase() || 'SEU NOME';
});

dateInput.addEventListener('input', () => {
    const value = dateInput.value
        .replace(/\D/g, '')
        .replace(/(.{2})/, '$1/');

    dateInput.value = value;
    cardDate.textContent = value || '00/00';
});

cvvInput.addEventListener('focus', () => card.classList.add('flip'));
cvvInput.addEventListener('blur', () => card.classList.remove('flip'));
cvvInput.addEventListener('input', () => {
    cardCvv.textContent = cvvInput.value || '000';
});

form.addEventListener('submit', async (event) => {
    event.preventDefault();

    if (!livroId) return;

    mensagem.textContent = 'Finalizando compra...';

    try {
        const response = await fetch(`/compras/${livroId}`, {
            method: 'POST',
            headers: { Authorization: `Bearer ${token}` }
        });

        const data = await response.json().catch(() => ({}));

        if (response.status === 401 || response.status === 403) {
            localStorage.removeItem('token');
            window.location.href = '/login/login.html';
            return;
        }

        if (!response.ok) {
            throw new Error(data.message || data.error || 'Não foi possível finalizar a compra.');
        }

        localStorage.removeItem('livroSelecionadoId');
        alert('Compra realizada com sucesso!');
        window.location.href = '/home/home.html';
    } catch (error) {
        mensagem.textContent = error.message;
    }
});
