const token = localStorage.getItem('token');
const mensagem = document.getElementById('mensagem');
const tabelaLivros = document.getElementById('lista-livros');
const tabelaUsuarios = document.getElementById('lista-usuarios');
const tabelaCompras = document.getElementById('lista-compras');
const buscarInput = document.getElementById('buscar');
const form = document.getElementById('livro-form');

let livros = [];

function authHeaders() {
    return {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
    };
}

function mostrarMensagem(texto, erro = true) {
    mensagem.textContent = texto || '';
    mensagem.style.color = erro ? '#c0392b' : '#27ae60';
}

function redirecionarLogin() {
    localStorage.removeItem('token');
    window.location.href = '/admin/login-admin.html';
}

async function verificarAdmin() {
    if (!token) {
        redirecionarLogin();
        return false;
    }

    const response = await fetch('/usuarios/perfil', {
        headers: { Authorization: `Bearer ${token}` }
    });

    if (!response.ok) {
        redirecionarLogin();
        return false;
    }

    const perfil = await response.json();
    if (perfil.role !== 'ADMIN') {
        alert('Acesso permitido apenas para administradores.');
        window.location.href = '/home/home.html';
        return false;
    }

    return true;
}

async function carregarDashboard() {
    const response = await fetch('/api/admin/dashboard', { headers: authHeaders() });
    if (!response.ok) throw new Error('Não foi possível carregar os dados do painel.');

    const dados = await response.json();
    document.getElementById('livros-total').textContent = dados.totalLivros ?? 0;
    document.getElementById('usuarios-total').textContent = dados.totalUsuarios ?? 0;
    document.getElementById('compras-total').textContent = dados.totalCompras ?? 0;
}

async function carregarLivros() {
    const response = await fetch('/livros', { headers: authHeaders() });
    if (!response.ok) throw new Error('Não foi possível carregar os livros.');

    livros = await response.json();
    renderizarLivros(livros);
}

function renderizarLivros(lista) {
    tabelaLivros.innerHTML = '';

    if (!lista.length) {
        tabelaLivros.innerHTML = '<tr><td colspan="5">Nenhum livro encontrado.</td></tr>';
        return;
    }

    lista.forEach(livro => {
        const preco = Number(livro.preco || 0).toLocaleString('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        });

        tabelaLivros.innerHTML += `
            <tr>
                <td>${livro.titulo}</td>
                <td>${livro.nomeAutor}</td>
                <td>${livro.anoEdicao}</td>
                <td>${preco}</td>
                <td>
                    <button class="action-btn editar" onclick="editarLivro(${livro.id})">Editar</button>
                    <button class="action-btn excluir" onclick="excluirLivro(${livro.id})">Excluir</button>
                </td>
            </tr>
        `;
    });
}

async function carregarUsuarios() {
    const response = await fetch('/api/admin/usuarios', { headers: authHeaders() });
    if (!response.ok) throw new Error('Não foi possível carregar os usuários.');

    const usuarios = await response.json();
    tabelaUsuarios.innerHTML = usuarios.length
        ? usuarios.map(usuario => `
            <tr>
                <td>${usuario.nomeCompleto || '-'}</td>
                <td>${usuario.email}</td>
                <td>${usuario.role}</td>
            </tr>
        `).join('')
        : '<tr><td colspan="3">Nenhum usuário encontrado.</td></tr>';
}

async function carregarCompras() {
    const response = await fetch('/api/admin/compras', { headers: authHeaders() });
    if (!response.ok) throw new Error('Não foi possível carregar as compras.');

    const compras = await response.json();
    tabelaCompras.innerHTML = compras.length
        ? compras.map(compra => `
            <tr>
                <td>${compra.usuarioNome || '-'}</td>
                <td>${compra.livroTitulo || '-'}</td>
                <td>${compra.dataCompra ? new Date(compra.dataCompra).toLocaleString('pt-BR') : '-'}</td>
            </tr>
        `).join('')
        : '<tr><td colspan="3">Nenhuma compra registrada.</td></tr>';
}

function editarLivro(id) {
    const livro = livros.find(item => item.id === id);
    if (!livro) return;

    document.getElementById('livro-id').value = livro.id;
    document.getElementById('titulo').value = livro.titulo;
    document.getElementById('nomeAutor').value = livro.nomeAutor;
    document.getElementById('anoEdicao').value = livro.anoEdicao;
    document.getElementById('preco').value = livro.preco;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function excluirLivro(id) {
    if (!confirm('Deseja excluir este livro?')) return;

    const response = await fetch(`/livros/${id}`, {
        method: 'DELETE',
        headers: authHeaders()
    });

    if (!response.ok) {
        const erro = await response.json().catch(() => ({}));
        throw new Error(erro.message || erro.error || 'Erro ao excluir livro.');
    }

    mostrarMensagem('Livro excluído com sucesso.', false);
    await atualizarTudo();
}

function limparFormulario() {
    form.reset();
    document.getElementById('livro-id').value = '';
}

form.addEventListener('submit', async (event) => {
    event.preventDefault();

    const id = document.getElementById('livro-id').value;
    const livro = {
        titulo: document.getElementById('titulo').value.trim(),
        nomeAutor: document.getElementById('nomeAutor').value.trim(),
        anoEdicao: document.getElementById('anoEdicao').value.trim(),
        preco: Number(document.getElementById('preco').value)
    };

    const url = id ? `/livros/${id}` : '/livros';
    const method = id ? 'PUT' : 'POST';

    const response = await fetch(url, {
        method,
        headers: authHeaders(),
        body: JSON.stringify(livro)
    });

    if (!response.ok) {
        const erro = await response.json().catch(() => ({}));
        throw new Error(erro.message || erro.error || 'Erro ao salvar livro.');
    }

    limparFormulario();
    mostrarMensagem('Livro salvo com sucesso.', false);
    await atualizarTudo();
});

document.getElementById('limpar').addEventListener('click', limparFormulario);

document.getElementById('logout').addEventListener('click', () => {
    localStorage.removeItem('token');
    window.location.href = '/admin/login-admin.html';
});

buscarInput.addEventListener('input', () => {
    const termo = buscarInput.value.toLowerCase();
    const filtrados = livros.filter(livro =>
        livro.titulo.toLowerCase().includes(termo) ||
        livro.nomeAutor.toLowerCase().includes(termo)
    );
    renderizarLivros(filtrados);
});

document.querySelectorAll('.sidebar li').forEach(item => {
    item.addEventListener('click', () => {
        document.querySelectorAll('.sidebar li').forEach(li => li.classList.remove('ativo'));
        item.classList.add('ativo');
    });
});

async function atualizarTudo() {
    await Promise.all([
        carregarDashboard(),
        carregarLivros(),
        carregarUsuarios(),
        carregarCompras()
    ]);
}

(async function iniciar() {
    try {
        const admin = await verificarAdmin();
        if (!admin) return;
        await atualizarTudo();
        mostrarMensagem('');
    } catch (error) {
        mostrarMensagem(error.message);
    }
})();
