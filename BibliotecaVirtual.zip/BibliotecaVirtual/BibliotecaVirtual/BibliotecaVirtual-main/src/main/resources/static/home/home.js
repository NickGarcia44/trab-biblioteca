let listaLivros = [];

const token = localStorage.getItem('token');
const mensagem = document.getElementById('mensagem');

if (!token) {
    window.location.href = '/login/login.html';
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('livroSelecionadoId');
    window.location.href = '/login/login.html';
}

async function carregarLivros() {
    mensagem.textContent = 'Carregando livros...';

    try {
        const response = await fetch('/livros', {
            headers: { Authorization: `Bearer ${token}` }
        });

        if (response.status === 401 || response.status === 403) {
            logout();
            return;
        }

        if (!response.ok) {
            throw new Error('Erro ao carregar livros.');
        }

        listaLivros = await response.json();
        renderizarLivros(listaLivros);
    } catch (error) {
        mensagem.textContent = error.message;
    }
}

function renderizarLivros(livros) {
    const container = document.getElementById('books');
    container.innerHTML = '';

    if (!livros.length) {
        mensagem.textContent = 'Nenhum livro encontrado.';
        return;
    }

    mensagem.textContent = '';

    livros.forEach(livro => {
        const card = document.createElement('div');
        card.classList.add('book-card');

        const preco = Number(livro.preco || 0).toFixed(2).replace('.', ',');

        card.innerHTML = `
          <div class="book-cover">📘</div>
          <div class="book-title">${livro.titulo}</div>
          <div>${livro.nomeAutor || 'Autor não informado'}</div>
          <div>${livro.anoEdicao || ''}</div>
          <div class="book-price">R$ ${preco}</div>
          <button class="buy-btn" onclick="comprarLivro(${livro.id})">Comprar</button>
        `;

        container.appendChild(card);
    });
}

function comprarLivro(livroId) {
    localStorage.setItem('livroSelecionadoId', livroId);
    window.location.href = '/pagamento/pagamento.html';
}

function filtrarLivros() {
    const termo = document.getElementById('searchInput').value.toLowerCase();

    const filtrados = listaLivros.filter(livro =>
        livro.titulo.toLowerCase().includes(termo) ||
        (livro.nomeAutor && livro.nomeAutor.toLowerCase().includes(termo))
    );

    renderizarLivros(filtrados);
}

carregarLivros();
